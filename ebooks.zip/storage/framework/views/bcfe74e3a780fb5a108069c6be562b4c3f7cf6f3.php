
<?php $__env->startSection('content'); ?>
<div class="margin-bottom">
<div class="row">
<div class="col-sm-9"><h1>Books</h1></div>
<div class="col-sm-3">
<button class="btn btn-lg btn-primary btn-block" data-toggle="modal" data-target="#exampleModal">Add</button></div>
</div>
</div> 
<table class="table table-bordered table-hover">
    <thead class="bg-light">
    <th>#</th>
        <th colspan="2">Title</th>
        <th>Price</th>
        <th>Author</th>
        <th>Category</th>
        <th>Created at</th>
        <th>Action</th>
    </thead>
    <tbody> 
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <tr>
        <td><?php echo e($key + 1); ?></td>
                <td>
                <img src="<?php echo $book->cover; ?>" alt="" style="width:30px">
                </td>
                <td><a href="<?php echo e(route('books.edit',$book->id)); ?>"><?php echo e($book->title); ?></a></td>
                <td><?php echo e($book->price); ?></td>
                <td><?php echo e($book->author); ?></td>
                <td><?php echo e($book->category); ?></td>
                <td><?php echo e($book->created_at); ?></td>
                <td><a href="<?php echo e(route('books.delete',$book->id)); ?>" class="btn btn-danger">x</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan='4'>No data found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table> 







<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-m1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-slideout modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('books.add')); ?>" method="post"  enctype="multipart/form-data"  >
        <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <strong>File</strong>
                <input type="text" name="file" class="form-control">
            </div>
            <div class="form-group">
                <strong>Title</strong>
                <input type="text" name="title" class="form-control">
            </div>
            <div class="form-group">
                <strong>Price</strong>
                <input type="text" name="price"  class="form-control">
            </div>
            <div class="form-group">
                <strong>Cover</strong><br>
                <input type="text" name="cover" placeholder="Enter image url here" class="form-control">
            </div>
            <div class="form-group">
                <strong>Author</strong>
                <input type="text" name="author" class="form-control">
            </div>
            <div class="form-group">
                <strong>Category</strong>
                <input type="text" name="category" class="form-control">
            </div>
            <div class="form-group">
                <strong>Description</strong>
                <textarea name="description" class="form-control" id="" cols="30" rows="10"></textarea>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </div>
    
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/cms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>