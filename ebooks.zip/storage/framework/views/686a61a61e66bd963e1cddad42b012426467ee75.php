
<?php $__env->startSection('content'); ?>

<h1>Cart</h1>
<br>
<table class="table table-hover table-striped table-bordered">
    <thead class="table-dark">
        <th colspan='3'>Book</th> 
        <th>Quantity</th>
        <th>Price</th>
        <th>Total</th>
    </thead>
    <tbody>  
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>
        <td>
        <a href="<?php echo e(route('cart.remove',$data->id)); ?>"><i class="fas fa-trash-alt text-danger"></i></a>
        </td>
            <td style="width:30px"><img src="<?php echo e($data->book->cover); ?>" style="width:30px" alt=""></td>
            <td><?php echo e($data->book->title); ?></td>
            <td><?php echo e($data->quantity); ?></td>
            <td  class="price"><?php echo e(number_format($data->book->price)); ?></td>
            <td  class="price"><?php echo e(number_format($data->book->price * $data->quantity)); ?></td>
        </tr>
        <?php $cart_total += $data->book->price * $data->quantity ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5">
                no data found
            </td>
        </tr>
        <?php endif; ?>
        <tr> 
        <td  class="text-right" colspan='5'>Sub total: </td>
        <td class="text-right">
        <h4 class="price"><?php echo e(number_format($cart_total)); ?></h4> 
        </td>
        
        </tr>
        <tr> 
        <td  class="text-right" colspan='5'>Shipping Fee: </td>
        <td class="text-right">
        <h4  class="price"><?php echo e($shipping_fee); ?></h4> 
        </td
        </tr>
        <tr> 
        <td  class="text-right" colspan='5'>Total: </td>
        <td class="text-right">
        <h4 class="price"><?php echo e(number_format($cart_total + $shipping_fee)); ?></h4> 
        </td> 
        </tr>
    </tbody>
</table>
<a href="<?php echo e(route('checkout')); ?>" class="btn btn-success">
    Checkout
</a>

<button class="btn btn-outline-success">
    Continue Shopping
</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>