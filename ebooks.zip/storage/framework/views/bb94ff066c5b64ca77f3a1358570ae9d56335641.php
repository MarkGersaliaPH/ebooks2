
<?php $__env->startSection('content'); ?>
 <div class="page-heading">
 <h1>View <?php echo e($book->title); ?></h1>
 Posted on: <?php echo e($book->created_at->diffForHumans()); ?><br>
 Last updated: <?php echo e($book->updated_at->diffForHumans()); ?><br>
 

 <div class="form-group">
<button class="btn btn-lg btn-primary" data-toggle="modal" data-target="#exampleModal">Preview</button> 
</div>
 </div>
<form action="<?php echo e(route('books.update')); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo e($book->id); ?>">
        <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <strong>File</strong>
                <input type="text" name="file" value="<?php echo e(isset($book->file) ? $book->file : ''); ?>" class="form-control form-control-lg">   
            </div>
            <div class="form-group">
                <strong>Title</strong>
                <input type="text" name="title" value="<?php echo e(isset($book->title) ? $book->title : ''); ?>" class="form-control form-control-lg">
            </div>
            <div class="form-group">
                <strong>Price</strong>
                <input type="text" name="price" value="<?php echo e(isset($book->price) ? $book->price : ''); ?>" class="form-control form-control-lg">
            </div>
            <div class="form-group">
            <img src="<?php echo $book->cover; ?>" alt="" style="width:80px">
            </div>
            <div class="form-group">
                <strong>Cover</strong><br>
                <input type="text" name="cover" value="<?php echo e(isset($book->cover) ? $book->cover : ''); ?>" placeholder="Enter image url here" class="form-control form-control-lg">
            </div>
            <div class="form-group">
                <strong>Author</strong>
                <input type="text" name="author" value="<?php echo e(isset($book->author) ? $book->author : ''); ?>" class="form-control form-control-lg">
            </div>
            <div class="form-group">
                <strong>Category</strong>
                <input type="text" name="category" value="<?php echo e(isset($book->category) ? $book->category : ''); ?>" class="form-control form-control-lg">
            </div>
            <div class="form-group">
                <strong>Description</strong>
                <textarea name="description" class="form-control form-control-lg" id="" cols="30" rows="10"> <?php echo e(isset($book->description) ? $book->description : ''); ?></textarea>
            </div> 
            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">cancel</button>
        <button type="submit" class="btn btn-primary">Save changes</button> 
    
    </form>


 
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel4" aria-hidden="true">
  <div class="modal-dialog modal-dialog-slideout modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Preview</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">  
      
      <div class="holds-the-iframe"> 
      <iframe src="<?php echo e(isset($book->file) ? $book->file : ''); ?>" style="height: 800px;width:100%;" frameborder="0"></iframe>
        </div>
      </div> 
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/cms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>